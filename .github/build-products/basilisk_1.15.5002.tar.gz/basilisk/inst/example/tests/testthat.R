library(testthat)
library(son.of.basilisk)
test_check("son.of.basilisk")
