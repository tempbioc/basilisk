from setuptools import setup

setup(name='test_dummy',
      version='0.1',
      description='Dummy test package',
      url='http://github.com/LTLA/basilisk',
      author='Aaron Lun',
      author_email='infinite.monkeys.with.keyboards@gmail.com',
      license='GPL-3',
      packages=['test_dummy'],
      zip_safe=False)

